# Ansible Collection: imjoseangel.general

![MasterDeployCI](https://github.com/imjoseangel/generalcollection/workflows/MasterDeployCI/badge.svg)

Install with:

```sh
ansible-galaxy collection install imjoseangel.general
```

